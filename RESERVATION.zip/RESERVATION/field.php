<html>
<title></title>
<head>

<style>

</style>
</head>
<body>
<script type="text/javascript">alert("Your Profile Account is still ongoing!,Sorry for the inconvinience!")</script>
<button type='a' onclick=''><img src="pics/Capture.PNG" alt="" /></BR><A href='GALLERY.PHP'>Back</A></button>
</body>
</html>