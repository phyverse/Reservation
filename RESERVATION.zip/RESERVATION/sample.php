
<script>if(confirm('Are you sure you want to Logout?'))
{window.location='Logout.php';
}else{
window.location='gallery.php';
}
</script>