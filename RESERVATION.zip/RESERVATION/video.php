<!DOCTYPE html> 
<html>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script> 
<body> 
<center>

<video width="700px"; height="600px" controls>

  <source src="HD Film Countdown (pink).mp4" type="video/mp4">
  <source src="mov_bbb.ogg" type="video/ogg">
  Your browser does not support HTML5 video.</video>

<p>
Video courtesy of 
<a href="http://www.youtube.com/" target="_blank">The Movie</a>.
</p>
</center>


<script><button type="button" onclick="JavaScript:alert('Success!. See the output at your pictures library')">
<img src="pics/print.jpg" alt="Klematis" />
<br />
<A href="Login.php">Print</A></button></script>
<script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0','width','121','height','28','src','text1','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','text1' ); //end AC code
</script><noscript>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="121" height="28">
  <param name="movie" value="text1.swf">
  <param name="quality" value="high">
  <embed src="text1.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="121" height="28" ></embed>
</object>
</noscript>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="124" height="42" id="Untitled.swf" align="middle">
	<param name="allowScriptAccess" value="sameDomain">
	<param name="movie" value="Untitled.swf">
	<param name="quality" value="high">
	<param name="bgcolor" value="#ffffff">
	<embed src="Untitled.swf" quality="high" bgcolor="#ffffff" width="124" height="42" name="Untitled.swf" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">
</object>

</body> 
</html>